﻿=== Red No Tail Cursor Set ===

By: MJD362

Download: http://www.rw-designer.com/cursor-set/rednotail

Author's decription:

A simple red cursor without a tail.

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.