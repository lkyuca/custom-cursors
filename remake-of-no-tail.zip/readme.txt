﻿=== remake of no tail Cursor Set ===

By: a_person (http://www.rw-designer.com/user/109220) iyancuy037@gmail.com

Download: http://www.rw-designer.com/cursor-set/remake-of-no-tail

Author's description:

remake of my previous no tail cursor

you can reupload this on any platform but do not ever confirm that its yours and include credit



==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.